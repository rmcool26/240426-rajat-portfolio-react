# Research notes

## Wall of Portfolios (wallofportfolios.in)
- Curated Indian-led showcase of designer portfolios. Categories include Minimalist (880+), Dark (410+), Interactive (330+), Creative, Modern Layout.
- **Portfolios of the Month** reviewed: Eemon Roy, Dharmesh Nayak, Aditya Muralidhar, Vaibhav Verma, Rashmi Saini.

| Portfolio | What stands out | Build |
| --- | --- | --- |
| Vaibhav Verma | TV-style video intro; case studies alternate left/right, each with two metrics; Fraunces italic used as an accent with Inter + Space Grotesk | Plain JS + Lenis smooth scroll |
| Eemon Roy | Animated box hero; Awwwards nominee; about 8 videos of work | Custom build |
| Dharmesh Nayak | Dark canvas intro; PP Neue Montreal type; very restrained after the intro | Framer |
| Aditya Muralidhar | Dotted grid; typing headline with redacted red bars; sound toggle | Lenis |
| Rashmi Saini | Sunflower "gate" intro; around 32 videos of work | Custom build |

Also reviewed (Rajat's references): Pleurat, Nicole Roberts, Drew Hansen.

**Shared pattern:** one memorable interactive moment at the top, then calm, crafted sections of real work (often video), personality in small details, fast load, no heavy 3D. That is why the plan uses one hero moment + calm enterprise-grade sections.

## What hiring managers want (2026)
- **Fountain Institute:** 3–5 case studies, not 10; at least one real decision with trade-offs; AI shown as judgement rather than tool listing. Figma's 2026 survey: 73% of design managers want AI-tool proficiency.
- **Mantlr:** lead with business framing (problem, metric) before process; 2–3 key decisions; end with honest reflection.
- **UX University:** first scan takes seconds (6–8 s claim, unsourced), so the first case title and image must signal impact.
- **Leslie Yang:** state role, team and duration clearly; separate what you did from what the team did.
- **Applied to Rajat:** 5 deep case studies; each opens with the business problem and outcome; role/team/duration up front; 1–2 decisions with before/after; "what I'd change"; pvNXT Help as the "how I use AI" example; shipped work first; must work on phones.

## Target employers
KPMG, Deloitte, EY (Big 4 consulting: breadth across sectors, enterprise calm, process clarity, accessibility), Morgan Stanley (fintech, data density, trust), L&T and Tech Mahindra (enterprise/industrial, GovTech, complex workflows). Role: Senior UX / Design Lead.

## Earlier brief
Rajat's earlier chat with the original brief: https://claude.ai/share/1c7a7814-0348-4671-99c5-88db03962a48 (team of 8+, UX + CRO loop, AI-assisted workflow, sectors).

## Sources
- https://wallofportfolios.in
- Fountain Institute, Mantlr, UX University and Leslie Yang articles on portfolio reviews (2025–2026); full links are in the audit doc's Sources section: https://claude.ai/artifact/471s6YopQCuMVbXkmNqDGa
