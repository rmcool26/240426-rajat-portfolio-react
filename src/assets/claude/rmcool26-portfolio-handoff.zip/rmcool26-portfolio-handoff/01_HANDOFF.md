# rmcool26 Portfolio Revamp: full handoff

Written 1 Nov 2026 at the end of a long working session, so a new chat can continue with the same understanding. Read this file end to end before doing anything.

---

## 1. Who Rajat is, and the goal

- **Rajat Mishra, aka rmcool26.** Product Designer, about 10 years (shipping since 2016). Hinglish is fine in chat; deliverables in plain English.
- **Now:** Terranxt (Jan 2022 to now), designing the **pvNXT** solar suite. He joined as the third member of the founding team. Leads an 8+ person team of designers, frontend developers and QA testers. Experience page also says "joined as designer #2 and scaled the design team from 2 to 12".
- **Career:** Dreamz Merchandising Solutions (2016–2019, junior web designer and developer, 20+ client sites) → Skymap Global (2020, software engineer with a UI focus, government GIS apps) → IIDE (2021, Executive Web Designer, +16% lead conversion, mentored 3 junior designers) → Terranxt (2022–now).
- **Sectors (6):** CleanTech/Solar, FinTech, PropTech/Real Estate, Healthcare AI, GovTech/GIS, EdTech.
- **Goal:** more interview calls and shortlists for **Senior UX / Design Lead** roles at **KPMG, Deloitte, EY, Morgan Stanley, L&T, Tech Mahindra**. The portfolio must also stand up next to the Wall of Portfolios "Portfolios of the Month" (wallofportfolios.in).
- **Audience decision:** mix all three: enterprise first (executive, calm, data-led), plus one award-level interactive moment, plus product-company depth (real decisions, trade-offs).
- **What he wants from the site:** pixel-perfect, interactive, animated where it earns it, fast on Indian 4G and on phones, and nothing that reads as AI slop.

## 2. How Rajat wants to work (non-negotiable)

1. **Section by section, page by page.** For each section: 3 design solutions (desktop + phone), he approves one (or a mix), then it gets added. Never build ahead of approval.
2. **No placeholders on anything that goes live.** Write real, final copy.
3. **Never invent facts.** No made-up numbers, testimonials, clients or results. If a fact is missing, the item is left out (not placeholdered) and the fact is asked for.
4. **Anti-slop rules** (his prompt is in `guides/anti-slop-prompt.md`): no buzzwords, no three-beat slogans, no "not just X, but Y", no em-dash crutches, no gradients/glassmorphism/blobs, no default fonts, no centred template layouts, no emoji decoration, no stock or AI images.
5. **His master website guide** (`guides/master-website-guide.md`) applies: gated workflow, options before building, real content, accessibility, mobile-first testing at 390 px, axe-core zero violations.
6. Ask questions only when the answer changes what gets built; max 4 at a time, multiple choice.
7. Think and design like a senior product designer with 20 years of craft; the portfolio must justify his 10 years.

## 3. Fact sheet (only use these numbers)

| Fact | Value | Source |
| --- | --- | --- |
| Title | Product Designer | Rajat, 31 Oct |
| Experience | 10 years, shipping since 2016 | Experience page |
| pvNXT EPCs | 4+ | Rajat |
| pvNXT customers | 20+ (homeowners and businesses, via Connect) | Rajat |
| Project time | 2–3 weeks, was 2–3 months | Rajat |
| Roof analysis | 10–15 minutes for the EPC designer, was a site visit | Rajat + site |
| Incubation | FITT, IIT Delhi | Site |
| pvNXT products | Studio (EPC), Connect (consumer), Go (installer), Proposal system, Field app, SCADA; also Atlas, Artha | Site + Help |
| IIDE | +16% lead conversion; mentored 3 junior designers (2021) | Experience page |
| Spade (Suhora, 2023) | Satellite imagery bought in 2–3 days instead of weeks | Work card (Rajat to confirm wording) |
| pvNXT Help | 3 long PDF guides → 58 short web guides; 63 screenshots; 17 videos mapped; 0 axe issues; 0 broken links of 132 | Help case study |
| Team | Leads 8+ (designers, frontend devs, QA) | Rajat's earlier brief |
| Users of pvNXT | India and UAE | Rajat |
| Email | rmcool26@gmail.com | Site |

**Do not use:** 20+ EPCs, 100+ users, 1k+ users, 6+ users (older/unverified, some only in unused code).

**Still missing (leave out until given):** Studio revamp feedback points and results; Bill Dixon and reNXT results and screens; XpertCoding details and screens; any pvNXT lead/sales figure; testimonial approvals; Suhora role.

## 4. Decisions log

| Decision | Choice |
| --- | --- |
| Hero headline | Keep "The cool guy who makes messy workflows work." It's his identity |
| Site guards (no copy / right-click) | Keep; he added them on purpose |
| Main case studies (5) | pvNXT Suite · pvNXT Studio revamp after user feedback (new, from Figma) · pvNXT Help · Suhora (website + Spade as one story) · IIDE |
| Everything else | "Other work", filterable by the 6 sectors (Bill Dixon, reNXT, XpertCoding, Skymap GIS, ArthaNXT, NDA fintech, AstonGreens, Terranxt, SCADA, Field app, decks…) |
| Dealer discount project (Saint-Gobain, NDA freelance) | Show blurred, brand hidden, labelled "Dealer discount portal for a global building-materials manufacturer (NDA)". Never invent a fake company name |
| Testimonials | I draft, each person approves before anything goes live. People: Deepanshu Sharma (Co-founder, Terranxt), Hina (Senior Graphic Designer), Shreya Yadav (Senior Python Developer), Aman Shrivastav (Associate Developer). Drafts in the audit doc |
| Motion assets | Animate from Figma screens (no screen recordings) |
| Deploy branch | `stage` (Rajat says). Live site matches latest commit on `stage` and `live`; `main` is the first commit only |
| Hero moments wanted | Messy → working, Sector switcher, Before/after slider |
| Direction | Mixed (enterprise + award + product). Earlier explorations A–D are superseded by section-by-section work |

## 5. Brand system (from the anti-slop audit, approved for the hero round)

- **Type:** Fraunces (headlines only; soft serif with character, carries the "cool guy" warmth) + IBM Plex Sans (body; engineering/enterprise credibility for Big 4) + IBM Plex Mono (numbers, labels, metadata).
- **Colour (3, no gradients):** Ink `#141A2E` (text, rules, dark footer), Paper `#F5F6F8` (cool white, not cream), Royal `#23409A` (links, numbers, one accent per screen). Placeholder-highlight yellow is never used on the live site.
- **Layout:** left-aligned 12-column grid, no centred sections, no rows of equal cards. Case studies as a numbered ledger with one big real screen each, alternating full-bleed and inset, outcome in Plex Mono. Page ends in a plain footer with the email in large type, not a CTA band.
- **Buttons:** square-ish (4px radius), Ink fill, Royal on hover. Text links underlined.
- **Motion:** purposeful only (the hero moment, hover pans on screens). Respect prefers-reduced-motion.

## 6. Anti-slop rewrites (live site → replacement)

| Where | Now | Replace with |
| --- | --- | --- |
| About hero | Not just a designer. A finisher. | I've designed software for 10 years. Since 2022 it's been pvNXT: six solar products, built from zero as the third member of the founding team. |
| Home line | Ideas to apps. Audits to fixes. | I turn calls, spreadsheets and WhatsApp threads into software that people use every day. |
| Work header | Cool work. Real problems. Shipped interfaces. | Projects, and what changed after they shipped |
| Work sub | designed to be used — not just shown | Websites, dashboards and apps. Most of them are live. |
| Process header | No theory. No Fluff. No double diamonds. | How a project runs with me, from the first call to the numbers after launch |
| 8 project taglines | "EPC, explained clean — sunny work…" | Cut; show one real outcome per project |
| Experience end | Need senior design thinking without the drama? | Hiring for a Senior UX or Design Lead role? Email me: rmcool26@gmail.com |
| Contact | Let's build something cool together. | Tell me what's broken. Email is the fastest way to reach me. |
| Footer | Designed & coded with ❤️ … | © 2026 Rajat Mishra. Designed and built by me. |

**Delete:** "Not sure where to start?", "Why work with me" cards, "rmcool26 decoded" card, emoji stat badges, all project taglines, Process page (fold into About "How I work"), and from Direction D: facts marquee, FAQ accordion, CTA band.

## 7. Sitemap

| Page | One job | Content |
| --- | --- | --- |
| Home | Who he is + best work in one scroll | Hero (approved option) · proof · 5 case studies · work by sector · how I work (UX + CRO loop: AI-assisted research/audit → stakeholder hypothesis sign-off → mid-fi + design system → UI/dev handoff → 1–2 months tracking in Clarity/HubSpot/GA → fix dead clicks/flows in 1–2 weeks) · testimonials (approved only) · footer with email |
| Work | Pick or browse | 5 case studies first, then Other work filtered by sector |
| Case study × 5 | Judgement on one real problem | Business problem first · role/team/duration · 1–2 decisions with before/after and trade-offs · outcome · what I'd change |
| Other work detail | Quick look | Readable WebP screens; v1 → v2 links for AstonGreens, Terranxt, pvNXT Help |
| About | The person | Story, photo, how I work with AI (pvNXT Help as the example), life outside work, testimonials |
| Experience | Timeline | H1, roles, stack |
| Contact | Reach him | Email as text + copy, LinkedIn, GitHub, resume, book a call |
| 404 | Get back | Message + the 5 case studies |

Page order for option rounds: **Home (section by section: Hero → Selected work → Work by sector → How I work → People → Footer)** → Work → Suite case study → Studio revamp → Help → Suhora → IIDE → Other work detail → About → Experience → Contact → 404.

## 8. Where things stand right now

- **Current gate:** Home · Section 1 Hero. Three options are on the Design canvas page "Home · 1 Hero", each desktop + phone, working and interactive:
  1. **Split with live project board** (recommended): statement left; right, a real pvNXT Studio screen buried under WhatsApp/Excel/AutoCAD/Word/phone/email mess that snaps into a clean project status (auto-plays, button to toggle).
  2. **Statement + sector rail:** big headline + photo; a ruled list of 6 sectors; hover/click shows the real screen and outcome (PropTech and Health AI show text only until screens arrive).
  3. **Proof first:** short statement, then the full-width Studio before/after slider (drag or arrow keys).
- **Waiting on Rajat:** pick 1, 2, 3 or a mix. Then: Section 2 "Selected work", 3 options.
- **Code status:** `stage` has the pvNXT Help case study (`/case/pvnxt-help`), the calm case-study layout, Suite v2 preview (`/case/terranxt-v2`), Home "Featured case studies" section and the Help Work card (commit d1d6bdc, pushed by Rajat). Suite v2 still uses the heavy SVG images.
- **Not done yet (Phase 1 foundations, no design change):** WebP images from Figma + lazy loading; one fact sheet in `content.ts`; title "Product Designer" everywhere; per-route titles/descriptions/OG image; delete unused code and packages; route-split JS; fix wrong live links (Suhora card points to srmfilms.in; Field App points to operationcomfortcontrolllc.com).

## 9. Links

| What | Link |
| --- | --- |
| Live portfolio | https://rmcool26.netlify.app/ |
| Repo | https://github.com/rmcool26/240426-rajat-portfolio-react (branches: `stage` = working, `live`, `lovable-stage`, `main` = first commit only) |
| Local folder (Windows) | D:\Personal\all_samples\final\240426-rajat-portfolio-react |
| Audit doc (Claude Docs) | https://claude.ai/artifact/471s6YopQCuMVbXkmNqDGa |
| Design canvas (all prototypes + hero options) | https://claude.ai/artifact/85N84YcL6CPJCYe2XXGyzz |
| Earlier interactive full-site preview | https://claude.ai/artifact/1kDSoChdYUf6HKS7vtS6AS |
| Earlier brief (another chat) | https://claude.ai/share/1c7a7814-0348-4671-99c5-88db03962a48 |
| pvNXT Help live / v1 | help.pvnxt.com · https://pvnxt-help.vercel.app/ |
| AstonGreens v1 / v2 | https://v2140926-ag-website.vercel.app/ · https://291026-astongreens-site.vercel.app/ |
| Terranxt v1 / v2 | https://071026-terranxt-website.vercel.app/ · https://v2-071026-terranxt-site.vercel.app/ |

## 10. Audit highlights (full version in the audit doc)

- **Weight:** project images are SVGs wrapping base64 PNGs. Live Suite page 54.8 MB; `/work` 11.9 MB; Studio detail 14.8 MB; one 324×198 card = 2 MB. WebP exports of the same screens: 664 KB for 12 images.
- **JS:** one 681 KB bundle, no route splitting.
- **Accessibility (axe-core):** Suite page 50 contrast failures + 25 small targets; detail pages 7 contrast failures each; Experience and Process have no H1; 404 no main landmark.
- **SEO:** `index.html` has the template TODO and "creative food" description; no OG image, Twitter card, canonical or sitemap; client-side only.
- **Dead code:** AboutCombined, CaseStudyCards, Marquee, OtherWork, ProjectModal, unrouted pages/CaseStudy.tsx; 46 of 49 shadcn UI files unused; recharts, react-day-picker, embla, cmdk, vaul, input-otp, resizable-panels, react-hook-form, zod unused; React Query unused. `src/docs`, `src/components/resume`, `src/stories` don't belong in `src`. 9 TypeScript errors.
- **Hard-coded colours** in CaseStudyPvNXT.tsx bypass the theme (dark mode broken there).

## 11. Research conclusions

- **Wall of Portfolios** (wallofportfolios.in): curated showcase; categories Minimalist (880+), Dark (410+), Interactive (330+), Creative, Modern Layout. Portfolios of the Month = Eemon Roy, Dharmesh Nayak, Aditya Muralidhar, Vaibhav Verma, Rashmi Saini.
- **Their shared pattern:** one memorable interactive moment at the top (Vaibhav's TV video intro; Eemon's animated box; Dharmesh's dark canvas intro; Aditya's typing line + redacted bars + sound toggle; Rashmi's sunflower gate), then calm, crafted sections of real work, often video. No heavy 3D; fast; built with plain JS + Lenis, or Framer.
- **Hiring sources (2026):** first scan is seconds; the first case title and image must signal impact; 3–5 deep case studies; open with business problem and outcome; 2–3 real decisions with trade-offs; honest reflection; shipped work over concepts; role/team/duration stated; AI shown as judgement (Figma 2026 survey: 73% of design managers want AI-tool proficiency); mobile-friendly.
- Detailed notes: `03_RESEARCH.md`.

## 12. Assets in this package

- `assets/images-webp/`: optimised real screens used in the prototypes (see `design-canvas/BLOB_MAP.md`).
- `assets/pvnxt-help-screens/`: the 22 pvNXT Help case study screenshots.
- `assets/figma-index/`: decoded maps of the 3 Figma files (which embedded image belongs to which frame), contact sheets and per-project group sheets. The .fig files themselves stay in Rajat's folder (`src/assets/figma/`, not committed; too big for GitHub).
- `design-canvas/`: every artboard source (.dc.html) and `canvas.json` from the Design canvas.
- `code/`: the pvNXT Help case study components and patch (already on `stage`).
- `guides/`: Rajat's master website guide and anti-slop prompt.
- `original-inputs/`: the pvNXT Help case study zip Rajat supplied.
