# Start here

This package lets a new chat pick up the rmcool26 portfolio revamp exactly where it stopped (1 Nov 2026, Home · Section 1 Hero, three options waiting for Rajat's pick).

## How to restart

1. Open a new chat.
2. Attach this whole zip (or at least `01_HANDOFF.md`, `02_DESIGN_SYSTEM_AND_COPY.md`, `03_RESEARCH.md` and the `guides/` folder).
3. Paste the prompt below as your first message.

---

## Starter prompt (copy everything between the lines)

---

I'm Rajat Mishra (rmcool26), Product Designer, 10 years. We're revamping my portfolio (https://rmcool26.netlify.app/, repo rmcool26/240426-rajat-portfolio-react, branch `stage`). Everything we decided so far is in the attached handoff package. Read `01_HANDOFF.md` fully first, then `02_DESIGN_SYSTEM_AND_COPY.md`, `03_RESEARCH.md`, and both guides in `guides/`.

How I work, strictly:
- Section by section, page by page. For each section give me 3 design solutions (desktop + phone, working and interactive), I approve one or a mix, then you add it. Never build ahead of my approval.
- No placeholders on anything that will go live. Real, final copy only.
- Never invent facts, numbers, clients or testimonials. If a fact is missing, leave the item out and ask me.
- Follow my anti-slop prompt and my master website guide.
- Ask only questions that change what you build, max 4, multiple choice.
- Think like a senior product designer with 20 years of craft; the result must justify my 10 years, win Big 4 / enterprise hiring managers, and stand next to Wall of Portfolios "Portfolios of the Month".

Where we are: Home · Section 1 Hero. Three options exist on my Design canvas (https://claude.ai/artifact/85N84YcL6CPJCYe2XXGyzz, page "Home · 1 Hero"). My pick is: [write 1, 2, 3 or a mix here]. Lock it, then give me 3 options for Section 2: Selected work.

Facts I can add now (optional): [Studio revamp feedback + results / Bill Dixon + reNXT results / XpertCoding details / pvNXT lead or sales figure / testimonial approvals / Suhora role]

---

## What's in this package

| File / folder | What it is |
| --- | --- |
| `01_HANDOFF.md` | Everything: who I am, goals, working rules, fact sheet, decisions, sitemap, current status, links, audit highlights |
| `02_DESIGN_SYSTEM_AND_COPY.md` | Type, colour, layout rules, hero copy, approved rewrites, the three hero options in detail |
| `03_RESEARCH.md` | Reference portfolios, Wall of Portfolios analysis, hiring-manager research, earlier brief |
| `design-canvas/` | Source of every prototype artboard + `BLOB_MAP.md` (which image each `/_blob/` id is) |
| `assets/images-webp/` | Optimised real screens and photo |
| `assets/pvnxt-help-screens/` | 22 pvNXT Help screenshots |
| `assets/figma-index/` | Maps and contact sheets of the 3 Figma files |
| `code/` | pvNXT Help case study components + patch (already on `stage`) |
| `guides/` | Master website guide + anti-slop prompt |
| `original-inputs/` | The pvNXT Help case study zip |

The audit doc and Design canvas also live on in Claude even if this chat is deleted (links in `01_HANDOFF.md`, section 9).
