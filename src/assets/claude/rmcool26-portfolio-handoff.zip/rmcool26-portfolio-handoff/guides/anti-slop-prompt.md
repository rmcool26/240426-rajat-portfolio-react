# Anti-AI-slop rules (as applied in this project)

Rajat's original anti-slop prompt was pasted in chat; this is the working version of its rules. If you still have the original text, drop it in this folder too and treat it as the source.

## Process
1. **Audit** every line of copy and every visual for slop.
2. **Rewrite** each flagged item: specific over impressive, plain words, real facts.
3. **Final check:** read it with the name removed. If it could be anyone's portfolio, it's still slop.
4. If there's code access, make the changes directly, then summarise what changed.

## Copy rules
- Specific beats impressive. Name the product, the user, the number.
- Never invent facts, numbers, clients or testimonials. When a fact is missing, leave the item out and ask (on live work, no visible placeholders).
- No buzzwords (seamless, leverage, elevate, robust, cutting-edge, passionate, empower, delightful, journey).
- No "not just X, but Y", no three-beat slogans ("Ideas to apps. Audits to fixes."), no rhetorical questions as headings.
- No em-dash crutches, no emoji decoration, no exclamation marks.
- Short sentences, active voice, first person.

## Visual rules
- No gradients, glassmorphism, blobs, glows, neon.
- No default fonts (Inter-only / system stack) and no cream-and-terracotta "AI aesthetic".
- No centred template hero, no rows of identical icon cards, no stock or AI-generated images.
- Real screens of real work; one accent colour; left-aligned grid.
