# Blob map

The artboards reference images as `/_blob/<id>` (Claude Design canvas asset store). Use this table to swap in the local files from `assets/images-webp/` when rebuilding outside the canvas.

| Blob id | Image | Local file |
| --- | --- | --- |
| 1cde8cd7862a6db35c48b25f14f2a0e8 | pvNXT Studio after the feedback revamp (roof boundary on satellite image) | studio-after.webp |
| 73202a7c7dcd4aeef81d7724cae73abb | pvNXT Studio before the feedback revamp (long step list + stringing layout) | studio-before.webp |
| 23891016297e64442b741575f1111c8b | Studio dialog "Missing a dimension", steps + short video | studio-video.webp |
| 697beae4b6f2610bf6fda1311160d079 | pvNXT Studio roof analysis | suite-studio.webp |
| 283fa29c11117ac1765e481bd3c594fb | pvNXT suite on laptop, tablet, phone | suite.webp |
| 531606eefb5bd175ed78c8e654a4048b | pvNXT Connect: choose how to measure your roof | suite-connect.webp |
| b5a8a44ceee16b8903c6b16edd047344 | pvNXT SCADA monitoring dashboard | suite-scada.webp |
| e70f84155caed3ec8f2bc2e0d6f7c3d9 | FigJam map of the EPC portal flow | suite-workflow.webp |
| e9e438b0c7b4050c402b2388226bd413 | pvNXT Help home | help.webp |
| 0ba1c705d45c09e91b7543ac12f1fc91 | Spade (Suhora) sign-in / marketplace | spade.webp |
| 43c4a1966cd6848d5479c0748eae3729 | IIDE course page | iide.webp |
| 6cc9c3575b46cac42493c36c73e44bad | ArthaNXT investment website | artha.webp |
| ef3547266399689a7e667aeecdf9087d | Photo of Rajat | rajat.webp |

`scada-alert.webp` is exported but not yet used on any artboard. The mapping comes from each image's alt text in the artboards.
