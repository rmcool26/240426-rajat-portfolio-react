# Design system, copy and the three hero options

## Tokens

```css
--ink:   #141A2E;  /* text, rules, buttons, dark footer */
--ink2:  #3A4258;  /* body copy */
--mute:  #5E667C;  /* labels, metadata */
--paper: #F5F6F8;  /* page background (cool white, not cream) */
--line:  #DCE0E8;  /* hairlines */
--royal: #23409A;  /* links, numbers, one accent per screen */
--card:  #FFFFFF;
```

Fonts (Google Fonts): `Fraunces` (opsz 9–144, 400/500/600, italic for one accent word), `IBM Plex Sans` 400/500/600, `IBM Plex Mono` 400/500.

```html
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,600&family=IBM+Plex+Sans:wght@400;500;600&family=IBM+Plex+Mono:wght@400;500&display=swap">
```

## Rules

- Headlines Fraunces 500, tight leading (.98), letter-spacing −0.035em. Desktop hero 66–78 px, phone 42–44 px.
- Body Plex Sans 15.5–17 px, line-height 1.5. Labels Plex Mono uppercase, 11–12.5 px, letter-spacing .06–.08em.
- Buttons: Ink fill, 4 px radius, min height 48 px (50 on phone), Royal on hover. Text links underlined.
- Desktop frame 1440 × 900, 80 px side margins. Phone frame 390 × 844, 20 px gutters. Touch targets ≥ 44 px.
- Left-aligned. No gradients, glass, blobs, emoji, stock/AI imagery, rows of identical cards, centred hero.
- Motion only where it shows the work. Every auto-play respects `prefers-reduced-motion` and stops after the user interacts.
- Nav (desktop): wordmark "Rajat Mishra" · Work · About · Experience · Contact · "Resume (PDF)". Phone: wordmark + 44 px menu button.

## Shared hero copy (final, no placeholders)

- **Eyebrow:** PRODUCT DESIGNER · 10 YEARS
- **H1:** The cool guy who makes messy workflows *work.* ("work." in Fraunces italic, Royal)
- **Sub:** I turn calls, spreadsheets and WhatsApp threads into software that people use every day. Right now that's pvNXT, where a rooftop solar project takes 2–3 weeks instead of 2–3 months.
- **Primary CTA:** See the pvNXT case study · secondary: rmcool26@gmail.com
- **Facts row:** FITT, IIT DELHI INCUBATED · 4+ EPCS · 20+ CUSTOMERS · SENIOR UX / LEAD ROLES, OPEN NOW

## The three hero options (Design canvas page "Home · 1 Hero")

### Option 1: Split with live project board (recommended)
- Left: eyebrow, H1, sub, CTA + email, facts row.
- Right: the real pvNXT Studio screen. In the "before" state it is blurred under six tags (WhatsApp, Excel, AutoCAD, Word, Phone call, Email) scattered at angles. In the "with pvNXT" state the tags snap into a neat status stack beside the clear screen.
- Auto-toggles every 3.4 s until the user presses "Show before / Show with pvNXT".
- Why: tells the "messy → working" story in one look, proves it with a real product screen, enterprise-calm but memorable.
- Files: `Hero1-Desktop.dc.html`, `Hero1-Phone.dc.html` (phone board height 236 px).

### Option 2: Statement + sector rail
- Big H1 with photo of Rajat; below, a ruled rail of 6 sectors (CleanTech, FinTech, PropTech, Health AI, GovTech, EdTech) as tabs. Auto-advances every 3.8 s; click/tap stops it.
- Each tab shows the real screen + one real outcome:
  - CleanTech · pvNXT: roof analysis in 10–15 minutes instead of a site visit
  - FinTech · ArthaNXT: a solar investment platform, designed from scratch
  - PropTech · Bill Dixon and reNXT: lead capture and conversion revamps (text panel; no screens yet)
  - Health AI · XpertCoding: UX research for autonomous medical coding (text panel; no screens yet)
  - GovTech · Spade by Suhora: satellite imagery in 2–3 days instead of weeks
  - EdTech · IIDE: lead conversion up 16% after the redesign
- Why: shows breadth across 6 sectors fast, which suits consulting (Big 4) recruiters. Weaker until PropTech/Health AI screens exist.
- Files: `Hero2-Desktop.dc.html` (H1 78 px), `Hero2-Phone.dc.html`.

### Option 3: Proof first, before/after slider
- Short statement row, then a full-width slider: pvNXT Studio before vs after the feedback round from the EPC designers. Drag or arrow keys (range input + `clip-path: inset(...)`), starts at 55%.
- Desktop sub: "Product designer, 10 years. Below is pvNXT Studio, the solar design tool I designed, before and after a round of feedback from the EPC designers who use it daily." CTA "Read how it changed".
- Why: most direct proof of design judgement. Depends on the Studio revamp case study, whose feedback points and results are still missing.
- Files: `Hero3-Desktop.dc.html`, `Hero3-Phone.dc.html`.

**Possible mix:** Option 1 as the hero, Option 3's slider opening the Studio revamp case study, Option 2's sector rail as the "Work by sector" section on Home.

## Next sections to design (3 options each, in order)

Home: 2 Selected work → 3 Work by sector → 4 How I work → 5 People (approved testimonials only) → 6 Footer with email.
Then the other pages in the order listed in `01_HANDOFF.md` section 7.

## Copy rewrites and deletions

See `01_HANDOFF.md` section 6. Those are the approved replacements for the current live copy.
